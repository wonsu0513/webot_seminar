#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/keyboard.h>
#include <webots/distance_sensor.h>
#include <webots/supervisor.h>
#include <webots/mouse.h>


#define TIME_STEP 64
#define MAX_SPEED  6.28


bool wonsu_zzang = false;


double* robot_controller(double* start_pos, double* target_pos) {
    double d = 0.070;
    static double motor_velocity[2];

    //printf("robot: x = %f, y = %f, theta = %f \n",start_pos[0],start_pos[1],start_pos[2]);        
    //printf("mouse: x = %f, y = %f, theta = %f \n",target_pos[0],target_pos[1],target_pos[2]);        
	
    double k_rho = 8;        //should be larger than 0, i.e, k_rho > 0
    double k_alpha = 20;      // k_alpha - k_rho > 0
    double k_beta = -0.08;     // should be smaller than 0, i.e, k_beta < 0
	
    double delta_x = (target_pos[0]-start_pos[0]);
    double delta_z = (target_pos[1]-start_pos[1]);
	
    double rho = sqrt(pow(delta_x,2) + pow(delta_z,2));    

    double alpha = -start_pos[2] + atan2(delta_x, delta_z);
    
    //printf("controller: rho = %f, alpha = %f \n", rho, alpha);     
       
    // analge with traget and current position 
   
    if(alpha > M_PI){
        alpha = alpha - (2*M_PI);
    }
    else if (alpha < -M_PI){
        alpha = alpha + (2*M_PI);
    }
    
    
    double beta = -start_pos[2] - alpha;     
    
    //printf("controller: rho = %f, alpha = %f, beta = %f \n", rho, alpha, beta);     

    double v = k_rho*rho; 
    double w = k_alpha*(alpha) + k_beta*beta;
    //printf("controller: v = %f, w = %f \n", v, w);     

    double vL = v + (d/2*w);    // P controller
    double vR = v - (d/2*w);      // P controller
    
    //printf("controller: vL = %f, vR = %f \n", vL, vR);
    
    //Clamp speed to the maximum speed.
    if(vL > MAX_SPEED){
    	vL = MAX_SPEED;
    }
    if(vR > MAX_SPEED){
    	vR = MAX_SPEED;
    }
    
    if(vL < -1*MAX_SPEED){
	vL = -1*MAX_SPEED;
    }
    if(vR < -1*MAX_SPEED){
	vR = -1*MAX_SPEED;
    }
    
    if(rho < 0.1){
      motor_velocity[0] = 0;
      motor_velocity[1] = 0;
    }
      
    else{
       motor_velocity[0] = vL;
       motor_velocity[1] = vR;
    }
    
    
    return motor_velocity;
}


int main(int argc, char **argv)
{
  wb_robot_init();
 
  WbNodeRef follower_robot = wb_supervisor_node_get_from_def("follower");
  WbFieldRef follower_translationField = wb_supervisor_node_get_field(follower_robot, "translation");
  WbFieldRef follower_rotationField = wb_supervisor_node_get_field(follower_robot, "rotation");
  
  WbDeviceTag follower_left_motor = wb_robot_get_device("left wheel motor");
  WbDeviceTag follower_right_motor = wb_robot_get_device("right wheel motor");
  WbDeviceTag follower_ps0 = wb_robot_get_device("ps0");
  WbDeviceTag follower_ps7 = wb_robot_get_device("ps7");


   wb_distance_sensor_enable(follower_ps0, TIME_STEP);
   wb_distance_sensor_enable(follower_ps7, TIME_STEP);
   

   wb_motor_set_position(follower_left_motor, INFINITY);
   wb_motor_set_position(follower_right_motor, INFINITY);
   wb_motor_set_velocity(follower_left_motor, 0);
   wb_motor_set_velocity(follower_right_motor, 0);
   
   
   WbNodeRef leader_mybot = wb_supervisor_node_get_from_def("e-puck");
   WbFieldRef leader_translationField = wb_supervisor_node_get_field(leader_mybot, "translation");
   WbFieldRef leader_rotationField = wb_supervisor_node_get_field(leader_mybot, "rotation");
  
  
   double left_speed= 0;
   double right_speed = 0;


   double initial_position[3] = {0.9,  0.0, 0.9 };

   wb_supervisor_field_set_sf_vec3f(follower_translationField, initial_position);
   
   while (wb_robot_step(TIME_STEP) != -1) 
   {    
    const double *translation = wb_supervisor_field_get_sf_vec3f(follower_translationField);
    const double *rotation = wb_supervisor_field_get_sf_rotation(follower_rotationField);
       
    const double *leader_translation = wb_supervisor_field_get_sf_vec3f(leader_translationField);
    const double *leader_rotation = wb_supervisor_field_get_sf_rotation(leader_rotationField);
    
    double robot_current_position[3] = {translation[0], translation[2], rotation[3]};
    double follower_goal_position[3] = {leader_translation[0], leader_translation[2], leader_rotation[3]};
    
    const double *wonsu = robot_controller(robot_current_position, follower_goal_position);
    
    left_speed=wonsu[0];
    right_speed=wonsu[1];
       
    wb_motor_set_velocity(follower_left_motor, left_speed);
    wb_motor_set_velocity(follower_right_motor,right_speed); 
          
  };

  wb_robot_cleanup();

  return 0;
}
